let Background = (function(){

    function Background(){
        this.onMessage();
        this.onRequest();
    }

    Background.prototype.onMessage = function(){
        chrome.extension.onMessage.addListener(this.onMessageResponse);
    }

    Background.prototype.onMessageResponse = function(type, response){
        return false;
    }

    Background.prototype.onRequest = function(){
        chrome.extension.onRequest.addListener(this.onRequestResponse);
    }

    Background.prototype.onRequestResponse = function(request, sender, sendResponse){
        return false;
    }

    return new Background;

})();
